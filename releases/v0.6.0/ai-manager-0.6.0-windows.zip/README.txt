Ai-manager 0.6.0 for Windows
Read docs/INSTALL.md and docs/RECOVERY.md.
Requires Python 3.10. This bundle is not a standalone executable.
Do not copy old credentials, inventory, run state or generated output into a new home.
